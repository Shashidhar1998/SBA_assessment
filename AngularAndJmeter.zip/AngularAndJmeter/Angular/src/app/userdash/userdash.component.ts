import { Component, OnInit } from '@angular/core';
import { ApiService } from '../service/api.service';
import { TrainingsService } from '../service/trainings.service';

import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../model/user.model';
import { Observable } from 'rxjs';
import { Training } from '../model/Training';

@Component({
  selector: 'app-userdash',
  templateUrl: './userdash.component.html',
  styleUrls: ['./userdash.component.css']
})
export class UserdashComponent implements OnInit {
  user:User;
  training:Training;
  onprogress:Training;
  constructor( private router: Router, private apiService: ApiService,private trainingsService:TrainingsService ) { }

  ngOnInit() {
    let userId = window.localStorage.getItem("user_id");
    
    
    if (!userId) {
      alert("Invalid action.")
      this.router.navigate(['login']);
      return;
    }
    this.apiService.getUserById(+userId)
    .subscribe( data => {
      this.user=data.result;
      
      console.log(data.result.first_name);
    });
    this.trainingsService.getCompleted(+userId)
    .subscribe( data => {
    this.training=data;
      console.log(data);
    });
    this.trainingsService.getOnProgress(+userId)
    .subscribe( data => {
    this.onprogress=data;
      console.log(data);
    });
    

  }
}




